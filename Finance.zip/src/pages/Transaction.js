import React from 'react';

function Transaction() {
  return (
    <div className='transaction'>
      <h1>Transaction</h1>
    </div>
  );
}

export default Transaction;
