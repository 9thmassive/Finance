import PieChart from './../charts/pieChart'

export default function PieCharts() {
    return (
        <div className="pieChart">
            <PieChart />
            <PieChart />
        </div>
    )
}
